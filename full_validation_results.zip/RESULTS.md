# Full validation comparison

Validation molecules: 12478. EMA weights; legacy beam 5.

| Model | Top1 | Top5 | Formula |
|---|---:|---:|---:|
| baseline | 62.91% | 89.10% | 89.64% |
| ce | 64.02% | 89.04% | 90.27% |
| ranking | 64.02% | 89.26% | 90.19% |

| Comparison | Top1 change | Paired 95% interval | Gains / losses |
|---|---:|---:|---:|
| rank_vs_baseline | +1.11 pp | +0.61 to +1.59 pp | 559 / 421 |
| ce_vs_baseline | +1.11 pp | +0.62 to +1.59 pp | 550 / 412 |
| rank_vs_ce | +0.00 pp | -0.38 to +0.38 pp | 299 / 299 |

This broader validation includes the original pilot subset. It is not an independent holdout.
The test split was not evaluated. No training was performed or weights promoted.
Single training seed; graph identity ignores stereochemistry. Intervals are exploratory and do not measure seed variability.
